
import Header from "@/components/layout/Header";
import Footer from "@/components/layout/Footer";
import Hero from "@/components/home/Hero";
import MarketOverview from "@/components/home/MarketOverview";
import TopMovers from "@/components/home/TopMovers";
import LatestNews from "@/components/home/LatestNews";
import FinPathPreview from "@/components/home/FinPathPreview";
import PopularTools from "@/components/home/PopularTools";

const Index = () => {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-grow">
        <Hero />
        
        <section className="py-8 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <MarketOverview />
          </div>
        </section>
        
        <section className="py-8 md:py-16 bg-slate-50">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <TopMovers />
              </div>
              <div className="lg:col-span-2">
                <LatestNews />
              </div>
            </div>
          </div>
        </section>
        
        <section className="py-8 md:py-16 bg-white">
          <div className="container mx-auto px-4">
            <FinPathPreview />
          </div>
        </section>
        
        <section className="py-8 md:py-16 bg-slate-50">
          <div className="container mx-auto px-4">
            <PopularTools />
          </div>
        </section>
      </main>
      
      <Footer />
    </div>
  );
};

export default Index;
