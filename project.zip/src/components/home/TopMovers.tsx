
import { Link } from "react-router-dom";
import { TrendingUp, TrendingDown } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// Mock data
const mockGainers = [
  { symbol: "AAPL", name: "Apple Inc.", price: "198.47", change: "+4.36", percentChange: "+2.25%" },
  { symbol: "MSFT", name: "Microsoft Corp.", price: "412.28", change: "+8.75", percentChange: "+2.17%" },
  { symbol: "AMZN", name: "Amazon.com Inc.", price: "182.62", change: "+3.24", percentChange: "+1.81%" },
  { symbol: "NVDA", name: "NVIDIA Corp.", price: "878.38", change: "+15.67", percentChange: "+1.82%" },
];

const mockLosers = [
  { symbol: "META", name: "Meta Platforms Inc.", price: "476.20", change: "-12.54", percentChange: "-2.57%" },
  { symbol: "TSLA", name: "Tesla Inc.", price: "175.34", change: "-4.86", percentChange: "-2.70%" },
  { symbol: "NFLX", name: "Netflix Inc.", price: "607.69", change: "-10.92", percentChange: "-1.77%" },
  { symbol: "GOOGL", name: "Alphabet Inc.", price: "164.26", change: "-2.82", percentChange: "-1.69%" },
];

const mockActiveOptions = [
  { symbol: "AAPL", name: "Apple $200 Call", price: "3.47", volume: "128.5K" },
  { symbol: "SPY", name: "S&P 500 ETF $490 Put", price: "2.76", volume: "98.3K" },
  { symbol: "TSLA", name: "Tesla $180 Call", price: "4.32", volume: "87.6K" },
  { symbol: "QQQ", name: "Invesco QQQ $415 Put", price: "1.98", volume: "76.2K" },
];

export default function TopMovers() {
  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-xl">Top Movers</CardTitle>
      </CardHeader>
      
      <Tabs defaultValue="gainers">
        <div className="px-6">
          <TabsList className="w-full">
            <TabsTrigger value="gainers" className="w-1/3">Gainers</TabsTrigger>
            <TabsTrigger value="losers" className="w-1/3">Losers</TabsTrigger>
            <TabsTrigger value="active" className="w-1/3">Active Options</TabsTrigger>
          </TabsList>
        </div>
        
        <CardContent className="pt-4">
          <TabsContent value="gainers">
            <div className="space-y-3">
              {mockGainers.map((stock) => (
                <Link 
                  key={stock.symbol}
                  to={`/markets/stocks/${stock.symbol}`} 
                  className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-md transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center">
                      <span className="font-semibold text-fin-primary">{stock.symbol}</span>
                      <span className="text-xs text-slate-600 ml-2 hidden md:inline">{stock.name}</span>
                    </div>
                    <div className="text-sm text-slate-600">${stock.price}</div>
                  </div>
                  <div className="flex items-center text-fin-positive">
                    <TrendingUp size={16} className="mr-1" />
                    <div className="text-right">
                      <div className="font-medium">{stock.percentChange}</div>
                      <div className="text-xs">{stock.change}</div>
                    </div>
                  </div>
                </Link>
              ))}
              <div className="pt-2">
                <Link 
                  to="/markets/movers" 
                  className="text-sm text-fin-teal hover:underline font-medium inline-block"
                >
                  View all top gainers →
                </Link>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="losers">
            <div className="space-y-3">
              {mockLosers.map((stock) => (
                <Link 
                  key={stock.symbol}
                  to={`/markets/stocks/${stock.symbol}`} 
                  className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-md transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center">
                      <span className="font-semibold text-fin-primary">{stock.symbol}</span>
                      <span className="text-xs text-slate-600 ml-2 hidden md:inline">{stock.name}</span>
                    </div>
                    <div className="text-sm text-slate-600">${stock.price}</div>
                  </div>
                  <div className="flex items-center text-fin-negative">
                    <TrendingDown size={16} className="mr-1" />
                    <div className="text-right">
                      <div className="font-medium">{stock.percentChange}</div>
                      <div className="text-xs">{stock.change}</div>
                    </div>
                  </div>
                </Link>
              ))}
              <div className="pt-2">
                <Link 
                  to="/markets/movers" 
                  className="text-sm text-fin-teal hover:underline font-medium inline-block"
                >
                  View all top losers →
                </Link>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="active">
            <div className="space-y-3">
              {mockActiveOptions.map((option) => (
                <Link 
                  key={option.symbol}
                  to={`/markets/options/${option.symbol}`} 
                  className="flex justify-between items-center p-2 hover:bg-slate-50 rounded-md transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center">
                      <span className="font-semibold text-fin-primary">{option.symbol}</span>
                      <span className="text-xs text-slate-600 ml-2 hidden md:inline">{option.name}</span>
                    </div>
                    <div className="text-sm text-slate-600">${option.price}</div>
                  </div>
                  <div className="text-right">
                    <div className="font-medium text-slate-700">Vol: {option.volume}</div>
                  </div>
                </Link>
              ))}
              <div className="pt-2">
                <Link 
                  to="/markets/options/most-active" 
                  className="text-sm text-fin-teal hover:underline font-medium inline-block"
                >
                  View all active options →
                </Link>
              </div>
            </div>
          </TabsContent>
        </CardContent>
      </Tabs>
    </Card>
  );
}
