
import { useState, useEffect } from "react";
import { TrendingUp, TrendingDown } from "lucide-react";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { useMarket } from "@/hooks/use-market";

// Mock data for market indices
const globalIndices = [
  { 
    id: "sp500", 
    name: "S&P 500", 
    value: "4,927.54", 
    change: "+18.36", 
    changePercent: "+0.37%", 
    isPositive: true 
  },
  { 
    id: "nasdaq", 
    name: "NASDAQ", 
    value: "15,982.08", 
    change: "+78.81", 
    changePercent: "+0.49%", 
    isPositive: true 
  },
  { 
    id: "dowjones", 
    name: "Dow Jones", 
    value: "38,239.66", 
    change: "-68.66", 
    changePercent: "-0.18%", 
    isPositive: false 
  },
  { 
    id: "russell", 
    name: "Russell 2000", 
    value: "2,063.67", 
    change: "+17.28", 
    changePercent: "+0.84%", 
    isPositive: true 
  },
];

const indiaIndices = [
  { 
    id: "nifty50", 
    name: "Nifty 50", 
    value: "22,643.40", 
    change: "+114.20", 
    changePercent: "+0.51%", 
    isPositive: true 
  },
  { 
    id: "sensex", 
    name: "Sensex", 
    value: "74,513.75", 
    change: "+389.72", 
    changePercent: "+0.53%", 
    isPositive: true 
  },
  { 
    id: "niftybank", 
    name: "Nifty Bank", 
    value: "48,276.15", 
    change: "-82.35", 
    changePercent: "-0.17%", 
    isPositive: false 
  },
  { 
    id: "nifty500", 
    name: "Nifty 500", 
    value: "20,854.75", 
    change: "+97.45", 
    changePercent: "+0.47%", 
    isPositive: true 
  },
];

export default function MarketOverview() {
  const { market } = useMarket();
  const [indices, setIndices] = useState(market === "global" ? globalIndices : indiaIndices);
  const [loading, setLoading] = useState(false);

  // Update indices when market selection changes
  useEffect(() => {
    setIndices(market === "global" ? globalIndices : indiaIndices);
  }, [market]);

  // For a real implementation, you would fetch real data here
  useEffect(() => {
    // Simulating data loading
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
    }, 1000);
    
    // Mock data update every 60 seconds
    const interval = setInterval(() => {
      setIndices(prevIndices => 
        prevIndices.map(index => {
          const random = Math.random() * 0.5 - 0.25; // Random between -0.25% and 0.25%
          const currentValue = parseFloat(index.value.replace(",", ""));
          const newValue = currentValue * (1 + random/100);
          const change = newValue - currentValue;
          const changePercent = (change / currentValue) * 100;
          
          return {
            ...index,
            value: newValue.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ","),
            change: (change >= 0 ? "+" : "") + change.toFixed(2),
            changePercent: (change >= 0 ? "+" : "") + changePercent.toFixed(2) + "%",
            isPositive: change >= 0
          };
        })
      );
    }, 60000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full">
      <div className="flex justify-between items-center mb-4">
        <h2 className="text-xl font-semibold text-fin-primary dark:text-white">
          {market === "global" ? "Global Market Overview" : "Indian Market Overview"}
        </h2>
        <Link to="/markets" className="text-sm font-medium text-fin-teal hover:underline">
          View All Markets
        </Link>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {indices.map((index) => (
          <Card key={index.id} className="overflow-hidden dark:border-slate-700">
            <CardContent className="p-4">
              <div className={`flex justify-between items-center ${loading ? 'animate-pulse-slow' : ''}`}>
                <div>
                  <Link to={`/markets/${index.id}`} className="font-semibold text-fin-primary hover:text-fin-secondary dark:text-white dark:hover:text-slate-300">
                    {index.name}
                  </Link>
                  <div className="text-lg font-bold mt-1 dark:text-white">{index.value}</div>
                </div>
                <div className={`flex flex-col items-end ${index.isPositive ? 'market-up' : 'market-down'}`}>
                  <div className="flex items-center">
                    {index.isPositive ? (
                      <TrendingUp size={18} className="mr-1" />
                    ) : (
                      <TrendingDown size={18} className="mr-1" />
                    )}
                    <span className="font-medium">{index.changePercent}</span>
                  </div>
                  <span className="text-sm">{index.change}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
