
import { Link } from "react-router-dom";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useMarket } from "@/hooks/use-market";

// Mock news data - Global
const mockGlobalNews = [
  {
    id: 1,
    title: "Fed Signals Potential Rate Cuts Amid Cooling Inflation Data",
    excerpt: "Federal Reserve officials hint at possible interest rate cuts later this year as inflation shows signs of easing, according to meeting minutes.",
    source: "Market Watch",
    time: "2 hours ago",
    category: "Economy",
    imageUrl: "https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 2,
    title: "Tech Giants Face New Antitrust Scrutiny as Regulatory Landscape Shifts",
    excerpt: "Major technology companies are bracing for increased regulatory oversight as new antitrust measures gain bipartisan support.",
    source: "Tech Insider",
    time: "4 hours ago",
    category: "Technology",
    imageUrl: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 3,
    title: "Renewable Energy Stocks Surge Following Climate Policy Announcement",
    excerpt: "Clean energy companies see significant stock price gains after new government initiatives to accelerate the transition to renewable energy sources.",
    source: "Green Invest",
    time: "6 hours ago",
    category: "Energy",
    imageUrl: "https://images.unsplash.com/photo-1508514177221-188b1cf16e9d?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 4,
    title: "Global Supply Chain Improvements Show Promising Signs for Inflation Relief",
    excerpt: "Key logistics indicators suggest easing of supply chain bottlenecks, potentially helping to reduce inflationary pressures in consumer goods.",
    source: "Economic Times",
    time: "8 hours ago",
    category: "Global Markets",
    imageUrl: "https://images.unsplash.com/photo-1566543294046-b52b26614cb6?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=250&q=80"
  }
];

// Mock news data - India
const mockIndiaNews = [
  {
    id: 1,
    title: "RBI Holds Benchmark Interest Rates Steady Amidst Inflation Concerns",
    excerpt: "The Reserve Bank of India has maintained key policy rates, prioritizing inflation control while supporting economic growth targets.",
    source: "Financial Express",
    time: "3 hours ago",
    category: "Economy",
    imageUrl: "https://images.unsplash.com/photo-1565698228480-539e49b54be8?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 2,
    title: "IT Sector Shows Promising Recovery with Strong Quarterly Results",
    excerpt: "Major Indian IT companies report better than expected Q1 results, signaling potential rebound in tech spending and project pipeline.",
    source: "The Economic Times",
    time: "5 hours ago",
    category: "Technology",
    imageUrl: "https://images.unsplash.com/photo-1573164574572-cb89e39749b4?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 3,
    title: "New Green Energy Policy to Boost Solar Manufacturing in India",
    excerpt: "Government announces incentives for domestic solar panel production, aiming to reduce imports and create manufacturing jobs.",
    source: "Mint",
    time: "7 hours ago",
    category: "Energy",
    imageUrl: "https://images.unsplash.com/photo-1509391366360-2e959784a276?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=250&q=80"
  },
  {
    id: 4,
    title: "Auto Sales Rise as Supply Chain Disruptions Ease and Demand Recovers",
    excerpt: "Passenger vehicle sales show strong monthly growth as semiconductor shortages diminish and consumer confidence improves.",
    source: "Business Standard",
    time: "9 hours ago",
    category: "Auto",
    imageUrl: "https://images.unsplash.com/photo-1552519507-da3b142c6e3d?ixlib=rb-1.2.1&auto=format&fit=crop&w=400&h=250&q=80"
  }
];

export default function LatestNews() {
  const { market } = useMarket();
  const news = market === "global" ? mockGlobalNews : mockIndiaNews;

  return (
    <Card className="dark:border-slate-700">
      <CardHeader className="flex flex-row justify-between items-center pb-2">
        <CardTitle className="text-xl dark:text-white">Latest Financial News</CardTitle>
        <Link to="/news" className="text-sm font-medium text-fin-teal hover:underline">
          View All News
        </Link>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {news.map((article) => (
            <div key={article.id} className="flex flex-col sm:flex-row gap-4">
              <div className="sm:w-1/3 mb-3 sm:mb-0">
                <Link to={`/news/article/${article.id}`}>
                  <img 
                    src={article.imageUrl} 
                    alt={article.title} 
                    className="w-full h-40 sm:h-28 object-cover rounded-lg"
                  />
                </Link>
              </div>
              <div className="sm:w-2/3">
                <Link to={`/news/article/${article.id}`} className="hover:text-fin-primary dark:text-white dark:hover:text-fin-teal">
                  <h3 className="font-semibold text-lg line-clamp-2 mb-1">{article.title}</h3>
                </Link>
                <p className="text-slate-600 text-sm line-clamp-2 mb-2 dark:text-slate-300">{article.excerpt}</p>
                <div className="flex items-center justify-between text-xs text-slate-500 dark:text-slate-400">
                  <span className="bg-slate-100 px-2 py-1 rounded dark:bg-slate-800">{article.category}</span>
                  <div className="flex gap-2">
                    <span className="font-medium">{article.source}</span>
                    <span>•</span>
                    <span>{article.time}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
